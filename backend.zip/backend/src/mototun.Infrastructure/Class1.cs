﻿namespace mototun.Infrastructure;

public class Class1
{

}
