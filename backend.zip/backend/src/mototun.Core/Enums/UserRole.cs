namespace mototun.Core.Enums
{
    public enum UserRole
    {
        Client = 1,
        Revendeur = 2,
        Fournisseur = 3,
        Admin = 4
    }
}